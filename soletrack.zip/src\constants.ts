export const SHIPPING_THRESHOLD = 500;
export const SHIPPING_FEE = 50;
export const LOW_STOCK_THRESHOLD = 30;
