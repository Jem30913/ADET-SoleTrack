import express from "express";
import path from "path";
import cors from "cors";
import mysql from "mysql2/promise";
import { createServer as createViteServer } from "vite";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import 'dotenv/config';

const PORT = 3000;
let pool: mysql.Pool;

const SHIPPING_THRESHOLD = 500;
const SHIPPING_FEE = 50;
const LOW_STOCK_THRESHOLD = 30;

async function initDb() {
  const host = process.env.DB_HOST || "127.0.0.1";
  const port = Number(process.env.DB_PORT) || 3308;
  const user = process.env.DB_USER || "root";
  const password = process.env.DB_PASS || "";
  const dbName = process.env.DB_NAME || "soletrack_node";

  const bootstrap = await mysql.createConnection({ host, port, user, password });
  await bootstrap.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await bootstrap.end();

  pool = mysql.createPool({ host, port, user, password, database: dbName, waitForConnections: true, connectionLimit: 10 });

  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      user_id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(100) NOT NULL UNIQUE,
      email VARCHAR(255) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      brand_name VARCHAR(255),
      first_name VARCHAR(50),
      last_name VARCHAR(50),
      role ENUM('customer', 'seller', 'admin') NOT NULL,
      status VARCHAR(20) DEFAULT 'active',
      deleted_at DATETIME NULL DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS seller_profiles (
      seller_id INT PRIMARY KEY,
      description TEXT,
      logo_url VARCHAR(500),
      banner_url VARCHAR(500),
      location VARCHAR(255),
      contact_email VARCHAR(255),
      phone VARCHAR(50),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS categories (
      category_id INT AUTO_INCREMENT PRIMARY KEY,
      category_name VARCHAR(255) NOT NULL,
      description TEXT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS sizes (
      size_id INT AUTO_INCREMENT PRIMARY KEY,
      size_value VARCHAR(20) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS products (
      product_id INT AUTO_INCREMENT PRIMARY KEY,
      seller_id INT NOT NULL,
      category_id INT NOT NULL,
      product_name VARCHAR(255) NOT NULL,
      description TEXT,
      base_price DECIMAL(10, 2) NOT NULL,
      image_url TEXT,
      status VARCHAR(20) DEFAULT 'active',
      deleted_at DATETIME NULL DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (seller_id) REFERENCES users(user_id),
      FOREIGN KEY (category_id) REFERENCES categories(category_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS inventory (
      inventory_id INT AUTO_INCREMENT PRIMARY KEY,
      product_id INT NOT NULL,
      size_id INT NOT NULL,
      stock_quantity INT DEFAULT 0,
      deleted_at DATETIME NULL DEFAULT NULL,
      FOREIGN KEY (product_id) REFERENCES products(product_id),
      FOREIGN KEY (size_id) REFERENCES sizes(size_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS reviews (
      review_id INT AUTO_INCREMENT PRIMARY KEY,
      product_id INT NOT NULL,
      user_id INT NULL,
      customer_name VARCHAR(255) NOT NULL,
      rating INT NOT NULL,
      comment TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products(product_id),
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS cart_items (
      cart_item_id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      product_id INT NOT NULL,
      size_id INT,
      quantity INT DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(user_id),
      FOREIGN KEY (product_id) REFERENCES products(product_id),
      FOREIGN KEY (size_id) REFERENCES sizes(size_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS orders (
      order_id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      total_amount DECIMAL(10, 2) NOT NULL,
      shipping_fee DECIMAL(10, 2) DEFAULT 0,
      status VARCHAR(20) DEFAULT 'pending',
      payment_status VARCHAR(20) DEFAULT 'unpaid',
      shipping_address TEXT,
      payment_method VARCHAR(50),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS order_items (
      order_item_id INT AUTO_INCREMENT PRIMARY KEY,
      order_id INT NOT NULL,
      product_id INT NOT NULL,
      size_id INT,
      quantity INT NOT NULL,
      price_at_purchase DECIMAL(10, 2) NOT NULL,
      FOREIGN KEY (order_id) REFERENCES orders(order_id),
      FOREIGN KEY (product_id) REFERENCES products(product_id),
      FOREIGN KEY (size_id) REFERENCES sizes(size_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS order_status_history (
      history_id INT AUTO_INCREMENT PRIMARY KEY,
      order_id INT NOT NULL,
      status VARCHAR(20) NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (order_id) REFERENCES orders(order_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS sessions (
      token VARCHAR(64) PRIMARY KEY,
      user_id INT NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query("DELETE FROM sessions WHERE expires_at < NOW()");
  await seedData();
}

async function seedData() {
  const seedUser = async (username: string, email: string, pass: string, role: string, brand?: string | null, firstName?: string | null, lastName?: string | null) => {
    const [rows] = await pool.execute("SELECT 1 FROM users WHERE email = ?", [email]) as any;
    if (rows.length === 0) {
      const hash = await bcrypt.hash(pass, 10);
      await pool.execute(
        "INSERT INTO users (username, email, password_hash, role, status, brand_name, first_name, last_name) VALUES (?, ?, ?, ?, 'active', ?, ?, ?)",
        [username, email, hash, role, brand ?? null, firstName ?? null, lastName ?? null]
      );
    }
  };

  await seedUser("admin", "admin@soletrack.com", "admin123", "admin", "SoleTrack Admin", null, null);
  await seedUser("bicolartisan", "bicolartisan@soletrack.com", "seller123", "seller", "Bicol Artisan Footwear", "Carlos", "Reyes");
  await seedUser("abacaheritage", "abacaheritage@soletrack.com", "seller123", "seller", "Abaca Heritage Crafts", "Maria", "Santos");
  await seedUser("mayonfootwear", "mayonfootwear@soletrack.com", "seller123", "seller", "Mayon Footwear Co.", "Diego", "Fernandez");
  await seedUser("bicolandiaweaves", "bicolandiaweaves@soletrack.com", "seller123", "seller", "Bicolandia Weaves", "Lourdes", "Bautista");
  await seedUser("juandelacruz", "juan.delacruz@example.com", "customer123", "customer", null, "Juan", "dela Cruz");

  const [catRows] = await pool.execute("SELECT COUNT(*) as count FROM categories") as any;
  if (Number(catRows[0].count) === 0) {
    const catNames = ["Traditional", "Woven", "Casual", "Eco-Friendly"];
    const catDescs = [
      "Traditional abaca slippers and native footwear.",
      "Modern woven footwear with heritage patterns.",
      "Casual sandals for everyday comfort.",
      "Sustainable and eco-friendly footwear.",
    ];
    for (let i = 0; i < catNames.length; i++) {
      await pool.execute("INSERT INTO categories (category_name, description) VALUES (?, ?)", [catNames[i], catDescs[i]]);
    }

    for (const val of ["5", "6", "7", "8", "9", "10", "11", "12"]) {
      await pool.execute("INSERT INTO sizes (size_value) VALUES (?)", [val]);
    }

    const sizeRowsAll = await pool.execute("SELECT size_id FROM sizes ORDER BY size_id ASC") as any;
    const sizeId7 = sizeRowsAll[0][2].size_id;
    const sizeId8 = sizeRowsAll[0][3].size_id;
    const sizeId9 = sizeRowsAll[0][4].size_id;
    const sizeId10 = sizeRowsAll[0][5].size_id;
    const selectedSizeIds = [sizeId7, sizeId8, sizeId9, sizeId10];

    const [catIdRows] = await pool.execute("SELECT category_id FROM categories ORDER BY category_id ASC") as any;
    const cId = (idx: number) => catIdRows[idx].category_id;

    const getSellerId = async (email: string) => {
      const [rows] = await pool.execute("SELECT user_id FROM users WHERE email = ?", [email]) as any;
      return rows[0].user_id;
    };

    const sBicol = await getSellerId("bicolartisan@soletrack.com");
    const sAbaca = await getSellerId("abacaheritage@soletrack.com");
    const sMayon = await getSellerId("mayonfootwear@soletrack.com");
    const sWeaves = await getSellerId("bicolandiaweaves@soletrack.com");

    await pool.execute("INSERT IGNORE INTO seller_profiles (seller_id, description, logo_url, banner_url, location, contact_email, phone) VALUES (?, ?, ?, ?, ?, ?, ?)", [sBicol, "Bicol Artisan Footwear brings the soul of the Bicol region to every step. Handcrafted by master artisans using traditional abaca weaving techniques passed down through generations.", "https://images.pexels.com/photos/1181565/pexels-photo-1181565.jpeg?auto=compress&cs=tinysrgb&w=300", "https://images.pexels.com/photos/772478/pexels-photo-772478.jpeg?auto=compress&cs=tinysrgb&w=1200", "Legazpi City, Albay", "bicolartisan@soletrack.com", "+63 912 345 6789"]);
    await pool.execute("INSERT IGNORE INTO seller_profiles (seller_id, description, logo_url, banner_url, location, contact_email, phone) VALUES (?, ?, ?, ?, ?, ?, ?)", [sAbaca, "Abaca Heritage Crafts celebrates the timeless art of abaca fiber weaving. Every product tells a story of sustainable craftsmanship rooted in centuries of Bicolano tradition.", "https://images.pexels.com/photos/1058774/pexels-photo-1058774.jpeg?auto=compress&cs=tinysrgb&w=300", "https://images.pexels.com/photos/101891/pexels-photo-101891.jpeg?auto=compress&cs=tinysrgb&w=1200", "Naga City, Camarines Sur", "abacaheritage@soletrack.com", "+63 915 678 1234"]);
    await pool.execute("INSERT IGNORE INTO seller_profiles (seller_id, description, logo_url, banner_url, location, contact_email, phone) VALUES (?, ?, ?, ?, ?, ?, ?)", [sMayon, "Mayon Footwear Co. draws inspiration from the majestic Mayon Volcano. Our designs blend volcanic earth tones with modern comfort for the adventurous spirit.", "https://images.pexels.com/photos/26652738/pexels-photo-26652738.jpeg?auto=compress&cs=tinysrgb&w=300", "https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg?auto=compress&cs=tinysrgb&w=1200", "Daraga, Albay", "mayonfootwear@soletrack.com", "+63 917 890 5678"]);
    await pool.execute("INSERT IGNORE INTO seller_profiles (seller_id, description, logo_url, banner_url, location, contact_email, phone) VALUES (?, ?, ?, ?, ?, ?, ?)", [sWeaves, "Bicolandia Weaves brings the vibrant textile heritage of the Bicol region to contemporary footwear. Each pair features hand-embroidered patterns inspired by local culture.", "https://images.pexels.com/photos/15776449/pexels-photo-15776449.jpeg?auto=compress&cs=tinysrgb&w=300", "https://images.pexels.com/photos/834892/pexels-photo-834892.jpeg?auto=compress&cs=tinysrgb&w=1200", "Iriga City, Camarines Sur", "bicolandiaweaves@soletrack.com", "+63 919 234 5678"]);

    const pexels = (id: number) => `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop`;

    const products = [
      { seller_id: sBicol, cat_id: cId(0), name: "Classic Abaca Slipper", desc: "Traditional handcrafted abaca slippers, the soul of Bicolano footwear.", price: 250.00, img: pexels(6651966) },
      { seller_id: sBicol, cat_id: cId(3), name: "Tropical Native Sandal", desc: "Eco-friendly summer sandals made from recycled materials and abaca.", price: 450.00, img: pexels(33801366) },
      { seller_id: sBicol, cat_id: cId(1), name: "Heritage Woven Loafer", desc: "Infusing modern loafer design with intricate traditional weaving patterns.", price: 1250.00, img: pexels(825890) },
      { seller_id: sBicol, cat_id: cId(2), name: "Coastal Breeze Flip-flop", desc: "The ultimate casual slipper for shoreline walks and relaxed days.", price: 180.00, img: pexels(4996974) },
      { seller_id: sBicol, cat_id: cId(1), name: "Pinangat Print Espadrilles", desc: "Inspired by the spicy Bicolano dish, these espadrilles feature a bold pepper-red weave.", price: 680.00, img: pexels(2918562) },
      { seller_id: sBicol, cat_id: cId(2), name: "Abaca Weekend Slides", desc: "Lightweight slides perfect for weekend market trips across Legazpi.", price: 320.00, img: pexels(13696789) },
      { seller_id: sAbaca, cat_id: cId(0), name: "Hand-Loomed House Slippers", desc: "Plush abaca house slippers hand-loomed by Bicolano weavers using century-old techniques.", price: 290.00, img: pexels(7671670) },
      { seller_id: sAbaca, cat_id: cId(1), name: "Abaca & Leather Mules", desc: "A refined fusion of abaca fiber and genuine leather for modern artisan style.", price: 850.00, img: pexels(27204298) },
      { seller_id: sAbaca, cat_id: cId(0), name: "Bakya-Inspired Wooden Clogs", desc: "A contemporary take on the traditional Filipino bakya, carved from sustainable local wood.", price: 550.00, img: pexels(4277934) },
      { seller_id: sMayon, cat_id: cId(2), name: "Mayon Sunrise Sandals", desc: "Inspired by the golden sunrise over Mayon Volcano, crafted for comfort and style.", price: 420.00, img: pexels(26652738) },
      { seller_id: sMayon, cat_id: cId(2), name: "Albay Trail Hiking Sandals", desc: "Durable hiking sandals designed for the volcanic trails and rocky terrain of Albay.", price: 990.00, img: pexels(2385477) },
      { seller_id: sMayon, cat_id: cId(3), name: "Legazpi City Walkers", desc: "Eco-conscious city walkers made from recycled rubber and sustainable abaca blends.", price: 1200.00, img: pexels(3217370) },
      { seller_id: sWeaves, cat_id: cId(1), name: "Pili Nut Design Loafers", desc: "Elegant loafers featuring hand-embroidered pili nut shell patterns, a Bicol icon.", price: 1350.00, img: pexels(15776449) },
      { seller_id: sWeaves, cat_id: cId(2), name: "Bicol Striped Sneakers", desc: "Bold striped sneakers inspired by the colorful textiles of the Bicol region.", price: 1450.00, img: pexels(977912) },
      { seller_id: sWeaves, cat_id: cId(0), name: "Inaul Fabric Slides", desc: "Slides adorned with Inaul fabric, celebrating traditional Mindanao weaving reimagined in Bicol.", price: 380.00, img: pexels(12891610) },
    ];

    for (const prod of products) {
      await pool.execute(
        "INSERT INTO products (seller_id, category_id, product_name, description, base_price, image_url) VALUES (?, ?, ?, ?, ?, ?)",
        [prod.seller_id, prod.cat_id, prod.name, prod.desc, prod.price, prod.img]
      );
    }

    const [productRows] = await pool.execute("SELECT product_id FROM products ORDER BY product_id ASC") as any;

    const stockMap: Record<number, number[]> = {
      5: [15, 22, 18, 12],
      6: [20, 25, 15, 10],
      7: [12, 18, 24, 20],
      8: [8, 15, 12, 6],
      9: [10, 14, 18, 10],
      10: [25, 30, 20, 15],
      11: [10, 12, 15, 8],
      12: [6, 10, 14, 12],
      13: [8, 12, 16, 10],
      14: [10, 15, 20, 12],
      15: [20, 25, 18, 15],
    };

    for (let pi = 0; pi < productRows.length; pi++) {
      const pid = productRows[pi].product_id;
      const stocks = stockMap[pi + 1] || [15, 15, 15, 15];
      for (let si = 0; si < selectedSizeIds.length; si++) {
        await pool.execute(
          "INSERT INTO inventory (product_id, size_id, stock_quantity) VALUES (?, ?, ?)",
          [pid, selectedSizeIds[si], stocks[si]]
        );
      }
    }

    const reviews = [
      { pid: productRows[0].product_id, name: "Artisan Collector", rating: 5, comment: "Authentic feel and amazing comfort.", days: 30 },
      { pid: productRows[0].product_id, name: "Echo Buyer", rating: 4, comment: "Lovely craftsmanship. Slightly narrow.", days: 20 },
      { pid: productRows[4].product_id, name: "Bicol Foodie", rating: 5, comment: "The prints remind me of home — bold and beautiful!", days: 15 },
      { pid: productRows[6].product_id, name: "Weave Enthusiast", rating: 5, comment: "My abuelita would absolutely approve.", days: 12 },
      { pid: productRows[6].product_id, name: "Tourist from Manila", rating: 4, comment: "A bit stiff at first but softens beautifully after a week.", days: 8 },
      { pid: productRows[8].product_id, name: "Heritage Lover", rating: 5, comment: "Finally someone modernized the bakya. Brilliant.", days: 10 },
      { pid: productRows[9].product_id, name: "Beach Goer", rating: 5, comment: "Comfortable for long walks on the sand.", days: 6 },
      { pid: productRows[10].product_id, name: "Hiker Juan", rating: 4, comment: "Great grip on volcanic trail paths.", days: 4 },
      { pid: productRows[12].product_id, name: "Office Worker", rating: 5, comment: "Gets compliments every single day at the office.", days: 3 },
      { pid: productRows[13].product_id, name: "Fashion Forward", rating: 4, comment: "Love the stripes. Runs slightly small though.", days: 2 },
    ];

    for (const r of reviews) {
      await pool.execute(
        "INSERT INTO reviews (product_id, customer_name, rating, comment, created_at) VALUES (?, ?, ?, ?, DATE_SUB(NOW(), INTERVAL ? DAY))",
        [r.pid, r.name, r.rating, r.comment, r.days]
      );
    }

    const [customerRows] = await pool.execute("SELECT user_id FROM users WHERE email = ?", ["juan.delacruz@example.com"]) as any;
    const customerId = customerRows[0].user_id;

    const addresses = [
      "123 Magallanes Street, Legazpi City, Albay, 4500",
      "45 Peñaranda Street, Naga City, Camarines Sur, 4400",
      "78 Rizal Avenue, Tabaco City, Albay, 4511",
      "12 Maharlika Highway, Daraga, Albay, 4501",
      "56 Quezon Boulevard, Iriga City, Camarines Sur, 4431",
    ];
    const addr = (i: number) => `Juan dela Cruz, ${addresses[i % addresses.length]}`;

    // productRows lookup helper
    const p = (idx: number) => productRows[idx].product_id;
    const price = (idx: number) => products[idx].price;

    const orders = [
      { days: 28, status: "delivered", pay: "cod", items: [[p(0), 2, price(0)], [p(2), 1, price(2)]] },
      { days: 25, status: "delivered", pay: "gcash", items: [[p(1), 3, price(1)]] },
      { days: 21, status: "delivered", pay: "paymaya", items: [[p(4), 1, price(4)], [p(5), 2, price(5)]] },
      { days: 18, status: "delivered", pay: "cod", items: [[p(6), 2, price(6)], [p(8), 1, price(8)]] },
      { days: 14, status: "delivered", pay: "gcash", items: [[p(9), 2, price(9)]] },
      { days: 15, status: "cancelled", pay: "gcash", items: [[p(7), 2, price(7)]] },
      { days: 12, status: "shipped", pay: "paymaya", items: [[p(10), 1, price(10)], [p(11), 1, price(11)]] },
      { days: 10, status: "shipped", pay: "cod", items: [[p(12), 1, price(12)], [p(14), 2, price(14)]] },
      { days: 7, status: "confirmed", pay: "gcash", items: [[p(13), 1, price(13)]] },
      { days: 5, status: "pending", pay: "cod", items: [[p(6), 1, price(6)], [p(5), 3, price(5)]] },
      { days: 3, status: "pending", pay: "paymaya", items: [[p(11), 1, price(11)]] },
      { days: 2, status: "pending", pay: "cod", items: [[p(0), 1, price(0)]] },
    ];

    const calcSubtotal = (items: number[][]) => items.reduce((sum: number, item: number[]) => sum + item[1] * item[2], 0);
    const calcShipping = (subtotal: number) => subtotal > SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;

    for (const order of orders) {
      const subtotal = calcSubtotal(order.items);
      const shipping = calcShipping(subtotal);
      const total = subtotal + shipping;

      await pool.execute(
        "INSERT INTO orders (user_id, total_amount, shipping_fee, status, payment_method, shipping_address, created_at) VALUES (?, ?, ?, ?, ?, ?, DATE_SUB(NOW(), INTERVAL ? DAY))",
        [customerId, total, shipping, order.status, order.pay, addr(order.days), order.days]
      );

      const [orderResult] = await pool.execute("SELECT LAST_INSERT_ID() as oid") as any;
      const orderId = orderResult[0].oid;

      const statusFlow = ["pending", "confirmed", "shipped", "delivered"];
      const statusIdx = order.status === "cancelled" ? 0 : statusFlow.indexOf(order.status);
      const confirmedDays = Math.max(1, order.days - 3);
      const shippedDays = Math.max(2, order.days - 7);
      const deliveredDays = Math.max(3, order.days - 10);

      if (statusIdx >= 0) {
        await pool.execute(
          "INSERT INTO order_status_history (order_id, status, created_at) VALUES (?, ?, DATE_SUB(NOW(), INTERVAL ? DAY))",
          [orderId, "pending", order.days]
        );
      }
      if (statusIdx >= 1) {
        await pool.execute(
          "INSERT INTO order_status_history (order_id, status, created_at) VALUES (?, ?, DATE_SUB(NOW(), INTERVAL ? DAY))",
          [orderId, "confirmed", confirmedDays]
        );
      }
      if (statusIdx >= 2) {
        await pool.execute(
          "INSERT INTO order_status_history (order_id, status, created_at) VALUES (?, ?, DATE_SUB(NOW(), INTERVAL ? DAY))",
          [orderId, "shipped", shippedDays]
        );
      }
      if (statusIdx >= 3) {
        await pool.execute(
          "INSERT INTO order_status_history (order_id, status, created_at) VALUES (?, ?, DATE_SUB(NOW(), INTERVAL ? DAY))",
          [orderId, "delivered", deliveredDays]
        );
      }
      if (order.status === "cancelled") {
        await pool.execute(
          "INSERT INTO order_status_history (order_id, status, created_at) VALUES (?, ?, DATE_SUB(NOW(), INTERVAL ? DAY))",
          [orderId, "cancelled", order.days]
        );
      }

      for (const item of order.items) {
        await pool.execute(
          "INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) VALUES (?, ?, ?, ?)",
          [orderId, item[0], item[1], item[2]]
        );
      }
    }
  }
}

async function startServer() {
  await initDb();
  const app = express();
  app.use(cors());
  app.use(express.json());

  app.get("/api/health", (req, res) => {
    res.json({ status: "success", message: "API is healthy" });
  });

  app.get("/api/products", async (req, res) => {
    const { category, limit, id, seller_id } = req.query;

    if (id) {
      const [productRows] = await pool.execute(`
        SELECT p.*, c.category_name, u.brand_name,
               (SELECT SUM(stock_quantity) FROM inventory WHERE product_id = p.product_id) as total_stock,
               (SELECT AVG(rating) FROM reviews WHERE product_id = p.product_id) as average_rating,
               (SELECT COUNT(*) FROM reviews WHERE product_id = p.product_id) as total_reviews
        FROM products p
        JOIN categories c ON p.category_id = c.category_id
        JOIN users u ON p.seller_id = u.user_id
        WHERE p.product_id = ? AND p.deleted_at IS NULL
      `, [id]) as any;

      const product = productRows[0];
      if (product) {
        const [reviews] = await pool.execute(
          "SELECT * FROM reviews WHERE product_id = ? ORDER BY created_at DESC", [id]
        ) as any;
        const [inventory] = await pool.execute(`
          SELECT i.*, s.size_value
          FROM inventory i
          JOIN sizes s ON i.size_id = s.size_id
          WHERE i.product_id = ? AND i.deleted_at IS NULL
        `, [id]) as any;
        product.reviews = reviews;
        product.inventory = inventory;
        return res.json({ status: "success", data: product });
      } else {
        return res.status(404).json({ status: "error", message: "Product not found" });
      }
    }

    let query = `
      SELECT p.*, c.category_name, u.brand_name,
             (SELECT SUM(stock_quantity) FROM inventory WHERE product_id = p.product_id) as total_stock,
             (SELECT AVG(rating) FROM reviews WHERE product_id = p.product_id) as average_rating,
             (SELECT COUNT(*) FROM reviews WHERE product_id = p.product_id) as total_reviews
      FROM products p
      JOIN categories c ON p.category_id = c.category_id
      JOIN users u ON p.seller_id = u.user_id
      WHERE p.status = 'active' AND p.deleted_at IS NULL
    `;
    const params: any[] = [];

    if (category && category !== "All") {
      query += " AND c.category_name = ?";
      params.push(category);
    }

    if (seller_id) {
      query += " AND p.seller_id = ?";
      params.push(Number(seller_id));
    }

    query += " ORDER BY p.created_at DESC";

    if (limit) {
      query += " LIMIT ?";
      params.push(Number(limit));
    }

    const [products] = await pool.execute(query, params) as any;
    res.json({ status: "success", data: products });
  });

  app.get("/api/categories", async (req, res) => {
    const [categories] = await pool.execute("SELECT * FROM categories") as any;
    res.json({ status: "success", data: categories });
  });

  app.get("/api/sizes", async (req, res) => {
    const [sizes] = await pool.execute("SELECT * FROM sizes ORDER BY size_id ASC") as any;
    res.json({ status: "success", data: sizes });
  });

  app.get("/api/stores", async (req, res) => {
    const [rows] = await pool.execute(`
      SELECT u.user_id, u.username, u.brand_name, u.first_name, u.last_name,
             sp.description, sp.logo_url, sp.banner_url, sp.location,
             (SELECT COUNT(*) FROM products WHERE seller_id = u.user_id AND deleted_at IS NULL) as product_count
      FROM users u
      LEFT JOIN seller_profiles sp ON u.user_id = sp.seller_id
      WHERE u.role = 'seller' AND u.status = 'active' AND u.deleted_at IS NULL
      ORDER BY u.brand_name ASC
    `) as any;
    res.json({ status: "success", data: rows });
  });

  app.get("/api/stores/:id", async (req, res) => {
    const { id } = req.params;
    const [userRows] = await pool.execute(`
      SELECT u.user_id, u.username, u.brand_name, u.first_name, u.last_name, u.email,
             sp.description, sp.logo_url, sp.banner_url, sp.location, sp.contact_email, sp.phone
      FROM users u
      LEFT JOIN seller_profiles sp ON u.user_id = sp.seller_id
      WHERE u.user_id = ? AND u.role = 'seller' AND u.deleted_at IS NULL
    `, [id]) as any;

    if (userRows.length === 0) {
      return res.status(404).json({ status: "error", message: "Store not found" });
    }

    const [products] = await pool.execute(`
      SELECT p.*, c.category_name,
             (SELECT SUM(stock_quantity) FROM inventory WHERE product_id = p.product_id) as total_stock,
             (SELECT AVG(rating) FROM reviews WHERE product_id = p.product_id) as average_rating,
             (SELECT COUNT(*) FROM reviews WHERE product_id = p.product_id) as total_reviews
      FROM products p
      JOIN categories c ON p.category_id = c.category_id
      WHERE p.seller_id = ? AND p.status = 'active' AND p.deleted_at IS NULL
      ORDER BY p.created_at DESC
    `, [id]) as any;

    res.json({ status: "success", data: { ...userRows[0], products } });
  });

  const getAuthenticatedUser = async (req: express.Request) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return null;
    const token = authHeader.split(" ")[1];
    if (!token) {
      console.log("Auth failed: No token in header");
      return null;
    }
    try {
      const [sessionRows] = await pool.execute(
        "SELECT user_id FROM sessions WHERE token = ? AND expires_at > NOW()", 
        [token]
      ) as any;
      if (sessionRows.length === 0) {
        console.debug(`Auth failed: Session not found or expired for token: ${token.substring(0, 3)}...`);
        return null;
      }
      const session = sessionRows[0];
      console.debug(`Auth success: Found session for user_id: ${session.user_id}`);
      const [userRows] = await pool.execute("SELECT * FROM users WHERE user_id = ? AND deleted_at IS NULL", [session.user_id]) as any;
      if (userRows.length === 0) {
        console.debug("Auth failed: User not found for user_id:", session.user_id);
        return null;
      }
      return userRows[0];
    } catch (e) {
      console.error("Auth check failed with error:", e);
      return null;
    }
  };

  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    await pool.execute("DELETE FROM sessions WHERE expires_at < NOW()");
    const [rows] = await pool.execute("SELECT * FROM users WHERE email = ? AND deleted_at IS NULL", [email]) as any;
    const user = rows[0];

    if (user && await bcrypt.compare(password, user.password_hash)) {
      const { password_hash, ...userInfo } = user;
      const token = crypto.randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
      await pool.execute(
        "INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)", 
        [token, user.user_id, expiresAt]
      );
      res.json({ status: "success", data: { ...userInfo, token } });
    } else {
      res.status(401).json({ status: "error", message: "Invalid email or password" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    const { email, password, role, first_name, last_name, brand_name } = req.body;
    try {
      if (password.length < 8) {
        return res.status(400).json({ status: "error", message: "Heritage key must be at least 8 characters" });
      }

      const username = email.split("@")[0] + "_" + Math.floor(Math.random() * 1000);
      const hash = await bcrypt.hash(password, 10);
      
      // Phase 3: Set status to pending_approval for sellers
      const status = role === 'seller' ? 'pending_approval' : 'active';
      
      const [result] = await pool.execute(
        "INSERT INTO users (username, email, password_hash, role, first_name, last_name, brand_name, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [username, email, hash, role || "customer", first_name || null, last_name || null, brand_name || null, status]
      ) as any;

      const [userRows] = await pool.execute("SELECT * FROM users WHERE user_id = ?", [result.insertId]) as any;
      const user = userRows[0];
      const { password_hash, ...userInfo } = user;

      const token = crypto.randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
      await pool.execute("INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)", [token, user.user_id, expiresAt]);

      res.json({ status: "success", data: { ...userInfo, token } });
    } catch (error: any) {
      console.error("Registration error:", error);
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (user) {
      const { password_hash, ...userInfo } = user;
      return res.json({ status: "success", data: userInfo });
    }
    res.status(401).json({ status: "error", message: "Not logged in" });
  });

  app.post("/api/auth/logout", async (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader) {
      const token = authHeader.split(" ")[1];
      if (token) await pool.execute("DELETE FROM sessions WHERE token = ?", [token]);
    }
    res.json({ status: "success", message: "Logged out" });
  });

  app.get("/api/cart", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Login required" });

    const [items] = await pool.execute(`
      SELECT c.*, p.product_name as name, p.base_price as price, p.image_url,
             (SELECT stock_quantity FROM inventory WHERE product_id = p.product_id AND (size_id = c.size_id OR (c.size_id IS NULL AND size_id IS NULL)) AND deleted_at IS NULL LIMIT 1) as stock_quantity
      FROM cart_items c
      JOIN products p ON c.product_id = p.product_id
      WHERE c.user_id = ?
    `, [user.user_id]) as any;
    const total = (items as any[]).reduce((sum: number, item: any) => sum + (item.price * item.quantity), 0);
    res.json({ status: "success", data: { items, total } });
  });

  app.post("/api/cart/add", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Login required" });

    const { product_id, quantity, size_id } = req.body;

    const [existingRows] = await pool.execute(
      "SELECT cart_item_id, quantity FROM cart_items WHERE user_id = ? AND product_id = ? AND (size_id = ? OR (size_id IS NULL AND ? IS NULL))",
      [user.user_id, product_id, size_id, size_id]
    ) as any;
    const existing = existingRows[0];

    if (existing) {
      await pool.execute("UPDATE cart_items SET quantity = quantity + ? WHERE cart_item_id = ?", [quantity, existing.cart_item_id]);
    } else {
      await pool.execute("INSERT INTO cart_items (user_id, product_id, size_id, quantity) VALUES (?, ?, ?, ?)", [user.user_id, product_id, size_id, quantity]);
    }
    res.json({ status: "success", message: "Added to cart" });
  });

  app.put("/api/cart/update", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Login required" });

    const { id } = req.query;
    const { quantity } = req.body;
    await pool.execute("UPDATE cart_items SET quantity = ? WHERE cart_item_id = ? AND user_id = ?", [quantity, id, user.user_id]);
    res.json({ status: "success", message: "Cart updated" });
  });

  app.delete("/api/cart/remove", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Login required" });

    const { id } = req.query;
    await pool.execute("DELETE FROM cart_items WHERE cart_item_id = ? AND user_id = ?", [id, user.user_id]);
    res.json({ status: "success", message: "Item removed" });
  });

  app.post("/api/checkout", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Login required" });

    const { shipping_address, payment_method } = req.body;
    const conn = await pool.getConnection();

    try {
      await conn.beginTransaction();

      const [cartItems] = await conn.execute(`
        SELECT c.*, p.base_price
        FROM cart_items c
        JOIN products p ON c.product_id = p.product_id
        WHERE c.user_id = ?
      `, [user.user_id]) as any;

      if (cartItems.length === 0) {
        throw new Error("Cart is empty");
      }

      for (const item of cartItems) {
        const [invRows] = await conn.execute(`
          SELECT stock_quantity
          FROM inventory
          WHERE product_id = ? AND (size_id = ? OR (size_id IS NULL AND ? IS NULL)) AND deleted_at IS NULL
        `, [item.product_id, item.size_id, item.size_id]) as any;
        const inventory = invRows[0];

        if (!inventory || inventory.stock_quantity < item.quantity) {
          throw new Error(`Insufficient stock for product. Available: ${inventory?.stock_quantity || 0}`);
        }
      }

      const subtotal = (cartItems as any[]).reduce((sum: number, item: any) => sum + (item.base_price * item.quantity), 0);
      const shipping = subtotal > SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
      const total = subtotal + shipping;

      const [orderResult] = await conn.execute(
        "INSERT INTO orders (user_id, total_amount, shipping_fee, shipping_address, payment_method) VALUES (?, ?, ?, ?, ?)",
        [user.user_id, total, shipping, shipping_address, payment_method]
      ) as any;
      const orderId = orderResult.insertId;

      await conn.execute("INSERT INTO order_status_history (order_id, status) VALUES (?, ?)", [orderId, "pending"]);

      for (const item of cartItems) {
        await conn.execute(
          "INSERT INTO order_items (order_id, product_id, size_id, quantity, price_at_purchase) VALUES (?, ?, ?, ?, ?)",
          [orderId, item.product_id, item.size_id, item.quantity, item.base_price]
        );

        const [updateResult] = await conn.execute(`
          UPDATE inventory
          SET stock_quantity = stock_quantity - ?
          WHERE product_id = ?
          AND (size_id = ? OR (size_id IS NULL AND ? IS NULL))
          AND stock_quantity >= ?
          AND deleted_at IS NULL
        `, [item.quantity, item.product_id, item.size_id, item.size_id, item.quantity]) as any;

        if (updateResult.affectedRows === 0) {
          throw new Error("Inventory update failed - possibly insufficient stock during processing");
        }
      }

      await conn.execute("DELETE FROM cart_items WHERE user_id = ?", [user.user_id]);
      await conn.commit();

      res.json({ 
        status: "success", 
        data: { 
          order_id: orderId,
          subtotal,
          shipping,
          total,
          freeShippingThreshold: SHIPPING_THRESHOLD,
          standardShippingFee: SHIPPING_FEE
        } 
      });
    } catch (error: any) {
      await conn.rollback();
      console.error("Checkout failed:", error);
      res.status(400).json({ status: "error", message: error.message });
    } finally {
      conn.release();
    }
  });

  app.get("/api/orders/my", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Login required" });

    const [orders] = await pool.execute(`
      SELECT order_id, status as order_status, payment_status, total_amount, shipping_address, created_at as order_date
      FROM orders
      WHERE user_id = ?
      ORDER BY created_at DESC
    `, [user.user_id]) as any;

    for (const order of orders) {
      const [items] = await pool.execute(`
        SELECT oi.*, p.product_name, p.image_url, s.size_value
        FROM order_items oi
        JOIN products p ON oi.product_id = p.product_id
        LEFT JOIN sizes s ON oi.size_id = s.size_id
        WHERE oi.order_id = ?
        LIMIT 3
      `, [order.order_id]) as any;
      order.items = items;
    }
    res.json({ status: "success", data: orders });
  });

  app.get("/api/orders/details", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Login required" });

    const { id } = req.query;
    const [orderRows] = await pool.execute(`
      SELECT order_id, user_id, status as order_status, payment_status, total_amount, shipping_fee, shipping_address, created_at as order_date
      FROM orders
      WHERE order_id = ?
    `, [id]) as any;
    const order = orderRows[0];

    if (order) {
      if (order.user_id !== user.user_id && user.role !== "admin") {
        const [sellerRows] = await pool.execute(`
          SELECT 1 FROM order_items oi JOIN products p ON oi.product_id = p.product_id
          WHERE oi.order_id = ? AND p.seller_id = ?
        `, [id, user.user_id]) as any;

        if (sellerRows.length === 0) {
          return res.status(403).json({ status: "error", message: "Access denied" });
        }
      }

      const [items] = await pool.execute(`
        SELECT oi.*, p.product_name, p.image_url, s.size_value
        FROM order_items oi
        JOIN products p ON oi.product_id = p.product_id
        LEFT JOIN sizes s ON oi.size_id = s.size_id
        WHERE oi.order_id = ?
      `, [id]) as any;

      order.items = items;

      const [history] = await pool.execute(
        "SELECT status, created_at as date_updated FROM order_status_history WHERE order_id = ? ORDER BY created_at ASC",
        [id]
      ) as any;
      order.history = history;

      res.json({ status: "success", data: order });
    } else {
      res.status(404).json({ status: "error", message: "Order not found" });
    }
  });

  app.post("/api/reviews", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Unauthorized" });

    const { product_id, rating, comment } = req.body;
    if (!product_id || !rating) {
      return res.status(400).json({ status: "error", message: "Product ID and rating are required" });
    }
    if (Number(rating) < 1 || Number(rating) > 5) {
      return res.status(400).json({ status: "error", message: "Rating must be between 1 and 5" });
    }

    try {
      const customer_name = `${user.first_name || ""} ${user.last_name || ""}`.trim() || user.username || "Verified Artisan Patron";

      await pool.execute(
        "INSERT INTO reviews (product_id, user_id, customer_name, rating, comment) VALUES (?, ?, ?, ?, ?)",
        [product_id, user.user_id, customer_name, Number(rating), comment]
      );

      res.json({ status: "success", message: "Review submitted" });
    } catch (error: any) {
      res.status(500).json({ status: "error", message: error.message });
    }
  });

  app.post("/api/orders/simulate", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Login required" });

    const { id } = req.query;
    let orderQuery = "SELECT status FROM orders WHERE order_id = ?";
    let orderParams = [id];

    if (user.role === 'customer') {
      orderQuery += " AND user_id = ?";
      orderParams.push(user.user_id);
    } else if (user.role === 'seller') {
      orderQuery = `
        SELECT DISTINCT o.status 
        FROM orders o 
        JOIN order_items oi ON o.order_id = oi.order_id 
        JOIN products p ON oi.product_id = p.product_id 
        WHERE o.order_id = ? AND p.seller_id = ?
      `;
      orderParams = [id, user.user_id];
    }

    const [orderRows] = await pool.execute(orderQuery, orderParams) as any;
    const order = orderRows[0];
    if (!order) return res.status(404).json({ status: "error", message: "Order not found" });

    const statuses = ["pending", "confirmed", "shipped", "delivered"];
    const currentIndex = statuses.indexOf(order.status);

    if (order.status === "cancelled") {
      return res.json({ status: "success", message: "Cannot simulate status for cancelled order" });
    }

    if (currentIndex !== -1 && currentIndex < statuses.length - 1) {
      const nextStatus = statuses[currentIndex + 1];
      await pool.execute("UPDATE orders SET status = ? WHERE order_id = ?", [nextStatus, id]);
      await pool.execute("INSERT INTO order_status_history (order_id, status) VALUES (?, ?)", [id, nextStatus]);
      res.json({ status: "success", message: `Order updated to ${nextStatus}` });
    } else if (currentIndex === statuses.length - 1) {
      res.json({ status: "success", message: "Order already delivered" });
    } else {
      res.status(400).json({ status: "error", message: `Cannot simulate next status for current status: ${order.status}` });
    }
  });

  app.put("/api/orders/cancel", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Unauthorized" });

    const { id } = req.query;
    if (!id) return res.status(400).json({ status: "error", message: "Order ID required" });

    const [orderRows] = await pool.execute(
      "SELECT status FROM orders WHERE order_id = ? AND user_id = ?",
      [id, user.user_id]
    ) as any;
    const order = orderRows[0];
    if (!order) return res.status(404).json({ status: "error", message: "Order not found" });

    if (["shipped", "delivered", "cancelled"].includes(order.status)) {
      return res.status(400).json({ status: "error", message: "Cannot cancel order that is shipped, delivered, or already cancelled" });
    }

    await pool.execute("UPDATE orders SET status = 'cancelled' WHERE order_id = ?", [id]);
    await pool.execute("INSERT INTO order_status_history (order_id, status) VALUES (?, 'cancelled')", [id]);

    res.json({ status: "success", message: "Order cancelled" });
  });

  /**
   * Middlewares
   */
  const isSeller = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const user = await getAuthenticatedUser(req);
    if (user && user.role === "seller" && user.status === "active") {
      (req as any).user = user;
      next();
    } else {
      res.status(403).json({ status: "error", message: "Seller access required (and must be active)" });
    }
  };

  const isAdmin = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const user = await getAuthenticatedUser(req);
    if (user && user.role === "admin") {
      (req as any).user = user;
      next();
    } else {
      res.status(403).json({ status: "error", message: "Admin access required" });
    }
  };

  app.get("/api/seller/dashboard", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;

    const [statsRows] = await pool.execute(`
      SELECT
        (SELECT COUNT(*) FROM products WHERE seller_id = ? AND deleted_at IS NULL) as total_products,
        (SELECT CAST(SUM(stock_quantity) AS DOUBLE) FROM inventory i JOIN products p ON i.product_id = p.product_id WHERE p.seller_id = ? AND p.deleted_at IS NULL AND i.deleted_at IS NULL) as total_stock,
        (SELECT CAST(SUM(i.stock_quantity * p.base_price) AS DOUBLE) FROM inventory i JOIN products p ON i.product_id = p.product_id WHERE p.seller_id = ? AND p.deleted_at IS NULL AND i.deleted_at IS NULL) as inventory_value,
        (SELECT COUNT(*) FROM (
          SELECT p.product_id 
          FROM products p 
          JOIN inventory i ON p.product_id = i.product_id 
          WHERE p.seller_id = ? AND p.deleted_at IS NULL AND i.deleted_at IS NULL 
          GROUP BY p.product_id 
          HAVING SUM(i.stock_quantity) < ?
        ) as low_stock_products) as low_stock_count
    `, [sellerId, sellerId, sellerId, sellerId, LOW_STOCK_THRESHOLD]) as any;
    const stats = statsRows[0];

    const [trend] = await pool.execute(`
      SELECT DATE(o.created_at) as date, CAST(SUM(oi.quantity * oi.price_at_purchase) AS DOUBLE) as revenue
      FROM orders o
      JOIN order_items oi ON o.order_id = oi.order_id
      JOIN products p ON oi.product_id = p.product_id
      WHERE p.seller_id = ? AND o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
      GROUP BY DATE(o.created_at)
      ORDER BY DATE(o.created_at)
    `, [sellerId]) as any;

    const [topSelling] = await pool.execute(`
      SELECT p.product_id, p.product_name, SUM(oi.quantity) as units_sold
      FROM order_items oi
      JOIN products p ON oi.product_id = p.product_id
      WHERE p.seller_id = ?
      GROUP BY p.product_id, p.product_name
      ORDER BY units_sold DESC
      LIMIT 5
    `, [sellerId]) as any;

    res.json({ status: "success", data: { ...stats, trend, topSelling } });
  });

  app.get("/api/seller/products", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const [products] = await pool.execute(`
      SELECT p.*, c.category_name,
             (SELECT SUM(stock_quantity) FROM inventory WHERE product_id = p.product_id AND deleted_at IS NULL) as total_stock,
             (SELECT AVG(rating) FROM reviews WHERE product_id = p.product_id) as average_rating,
             (SELECT COUNT(*) FROM reviews WHERE product_id = p.product_id) as total_reviews
      FROM products p
      JOIN categories c ON p.category_id = c.category_id
      WHERE p.seller_id = ? AND p.deleted_at IS NULL
      ORDER BY p.created_at DESC
    `, [sellerId]) as any;

    for (const p of products) {
      const [inventory] = await pool.execute(`
        SELECT i.*, s.size_value
        FROM inventory i
        JOIN sizes s ON i.size_id = s.size_id
        WHERE i.product_id = ? AND i.deleted_at IS NULL
      `, [p.product_id]) as any;
      p.inventory = inventory;
    }

    res.json({ status: "success", data: products });
  });

  app.post("/api/seller/products", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const { product_name, description, base_price, category_id, image_url, inventory } = req.body;

    try {
      const [result] = await pool.execute(
        "INSERT INTO products (seller_id, category_id, product_name, description, base_price, image_url) VALUES (?, ?, ?, ?, ?, ?)",
        [sellerId, category_id, product_name, description, base_price, image_url]
      ) as any;
      const productId = result.insertId;

      if (inventory && Array.isArray(inventory)) {
        for (const item of inventory) {
          await pool.execute(
            "INSERT INTO inventory (product_id, size_id, stock_quantity) VALUES (?, ?, ?)",
            [productId, item.size_id, item.stock_quantity]
          );
        }
      }

      res.json({ status: "success", message: "Product added successfully", data: { product_id: productId } });
    } catch (error: any) {
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  app.put("/api/seller/products", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const { product_id, product_name, description, base_price, category_id, image_url, inventory } = req.body;

    const [ownerRows] = await pool.execute(
      "SELECT 1 FROM products WHERE product_id = ? AND seller_id = ?",
      [product_id, sellerId]
    ) as any;
    if (ownerRows.length === 0) {
      return res.status(403).json({ status: "error", message: "Product not found or access denied" });
    }

    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();

      await conn.execute(
        "UPDATE products SET product_name = ?, description = ?, base_price = ?, category_id = ?, image_url = ? WHERE product_id = ?",
        [product_name, description, base_price, category_id, image_url, product_id]
      );

      if (inventory && Array.isArray(inventory)) {
        for (const item of inventory) {
          if (Number(item.stock_quantity) < 0) {
            throw new Error("Stock quantity cannot be negative");
          }
          if (item.inventory_id) {
            await conn.execute(
              "UPDATE inventory SET stock_quantity = ? WHERE inventory_id = ? AND product_id = ?",
              [item.stock_quantity, item.inventory_id, product_id]
            );
          } else {
            await conn.execute(
              "INSERT INTO inventory (product_id, size_id, stock_quantity) VALUES (?, ?, ?)",
              [product_id, item.size_id, item.stock_quantity]
            );
          }
        }
      }

      await conn.commit();
      res.json({ status: "success", message: "Product updated" });
    } catch (error: any) {
      await conn.rollback();
      res.status(400).json({ status: "error", message: error.message });
    } finally {
      conn.release();
    }
  });

  app.delete("/api/seller/products", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const { id } = req.query;

    const [result] = await pool.execute(
      "UPDATE products SET deleted_at = NOW() WHERE product_id = ? AND seller_id = ?",
      [id, sellerId]
    ) as any;

    if (result.affectedRows > 0) {
      res.json({ status: "success", message: "Product deleted (soft delete)" });
    } else {
      res.status(404).json({ status: "error", message: "Product not found" });
    }
  });

  app.get("/api/seller/reports/sales", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const days = Number(req.query.days) || 7;

    const [metricsRows] = await pool.execute(`
      SELECT
        CAST(SUM(oi.quantity * oi.price_at_purchase) AS DOUBLE) as total_revenue,
        COUNT(DISTINCT o.order_id) as total_orders,
        CAST(AVG(o.total_amount) AS DOUBLE) as aov,
        COUNT(DISTINCT o.user_id) as total_customers,
        CAST(SUM(oi.quantity) AS DOUBLE) as products_sold,
        (SELECT COUNT(*) FROM orders o2 JOIN order_items oi2 ON o2.order_id = oi2.order_id JOIN products p2 ON oi2.product_id = p2.product_id WHERE p2.seller_id = ? AND o2.status = 'pending') as pending_orders_count
      FROM orders o
      JOIN order_items oi ON o.order_id = oi.order_id
      JOIN products p ON oi.product_id = p.product_id
      WHERE p.seller_id = ? AND o.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
    `, [sellerId, sellerId, days]) as any;
    const metrics = metricsRows[0];

    const [trend] = await pool.execute(`
      SELECT DATE(o.created_at) as date, CAST(SUM(oi.quantity * oi.price_at_purchase) AS DOUBLE) as revenue
      FROM orders o
      JOIN order_items oi ON o.order_id = oi.order_id
      JOIN products p ON oi.product_id = p.product_id
      WHERE p.seller_id = ? AND o.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
      GROUP BY DATE(o.created_at)
      ORDER BY DATE(o.created_at)
    `, [sellerId, days]) as any;

    const [categoryBreakdown] = await pool.execute(`
      SELECT c.category_name, CAST(SUM(oi.quantity * oi.price_at_purchase) AS DOUBLE) as value
      FROM order_items oi
      JOIN products p ON oi.product_id = p.product_id
      JOIN categories c ON p.category_id = c.category_id
      WHERE p.seller_id = ?
      GROUP BY c.category_id, c.category_name
    `, [sellerId]) as any;

    const [topSelling] = await pool.execute(`
      SELECT p.product_id, p.product_name, SUM(oi.quantity) as units_sold, CAST(SUM(oi.quantity * oi.price_at_purchase) AS DOUBLE) as revenue
      FROM order_items oi
      JOIN products p ON oi.product_id = p.product_id
      WHERE p.seller_id = ?
      GROUP BY p.product_id, p.product_name
      ORDER BY units_sold DESC
      LIMIT 10
    `, [sellerId]) as any;

    res.json({ status: "success", data: { metrics, trend, categoryBreakdown, topSelling } });
  });

  app.get("/api/seller/reviews", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const { product_id } = req.query as any;

    if (!product_id) {
      return res.status(400).json({ status: "error", message: "product_id is required" });
    }

    const [ownerCheck] = await pool.execute(
      "SELECT product_id FROM products WHERE product_id = ? AND seller_id = ? AND deleted_at IS NULL",
      [product_id, sellerId]
    ) as any;

    if (!ownerCheck.length) {
      return res.status(403).json({ status: "error", message: "Access denied" });
    }

    const [reviews] = await pool.execute(
      "SELECT review_id, customer_name, rating, comment, created_at FROM reviews WHERE product_id = ? ORDER BY created_at DESC",
      [product_id]
    ) as any;

    res.json({ status: "success", data: reviews });
  });

  app.get("/api/seller/orders", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const [orders] = await pool.execute(`
      SELECT DISTINCT o.order_id, o.total_amount, o.status as order_status, o.payment_status,
             o.shipping_address, o.payment_method, o.created_at as order_date,
             u.first_name, u.last_name
      FROM orders o
      JOIN order_items oi ON o.order_id = oi.order_id
      JOIN products p ON oi.product_id = p.product_id
      JOIN users u ON o.user_id = u.user_id
      WHERE p.seller_id = ?
      ORDER BY o.created_at DESC
    `, [sellerId]) as any;

    for (const order of orders) {
      const [items] = await pool.execute(`
        SELECT oi.*, p.product_name, s.size_value
        FROM order_items oi
        JOIN products p ON oi.product_id = p.product_id
        LEFT JOIN sizes s ON oi.size_id = s.size_id
        WHERE oi.order_id = ? AND p.seller_id = ?
      `, [order.order_id, sellerId]) as any;
      order.items = items;
    }

    res.json({ status: "success", data: orders });
  });

  app.put("/api/seller/orders/status", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const { order_id, status } = req.body;

    const validStatuses = ["pending", "confirmed", "shipped", "delivered", "cancelled"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ status: "error", message: "Invalid status" });
    }

    const [orderRows] = await pool.execute("SELECT status FROM orders WHERE order_id = ?", [order_id]) as any;
    const order = orderRows[0];

    if (!order) return res.status(404).json({ status: "error", message: "Order not found" });

    if (order.status === "delivered" || order.status === "cancelled") {
      return res.status(400).json({ status: "error", message: `Cannot update status of a ${order.status} order` });
    }

    const [hasItemsRows] = await pool.execute(`
      SELECT 1 FROM order_items oi JOIN products p ON oi.product_id = p.product_id
      WHERE oi.order_id = ? AND p.seller_id = ?
    `, [order_id, sellerId]) as any;

    if (hasItemsRows.length > 0) {
      await pool.execute("UPDATE orders SET status = ? WHERE order_id = ?", [status, order_id]);
      await pool.execute("INSERT INTO order_status_history (order_id, status) VALUES (?, ?)", [order_id, status]);
      res.json({ status: "success", message: `Order status updated to ${status}` });
    } else {
      res.status(403).json({ status: "error", message: "Access denied or order not found" });
    }
  });

  app.get("/api/seller/profile", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const [userRows] = await pool.execute("SELECT user_id, username, email, brand_name, first_name, last_name FROM users WHERE user_id = ?", [sellerId]) as any;
    const [profileRows] = await pool.execute("SELECT * FROM seller_profiles WHERE seller_id = ?", [sellerId]) as any;
    res.json({ status: "success", data: { ...userRows[0], profile: profileRows[0] || null } });
  });

  app.put("/api/seller/profile", isSeller, async (req, res) => {
    const sellerId = (req as any).user.user_id;
    const { brand_name, description, logo_url, banner_url, location, contact_email, phone } = req.body;
    if (brand_name) {
      await pool.execute("UPDATE users SET brand_name = ? WHERE user_id = ?", [brand_name, sellerId]);
    }
    await pool.execute(`
      INSERT INTO seller_profiles (seller_id, description, logo_url, banner_url, location, contact_email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE description = VALUES(description), logo_url = VALUES(logo_url), banner_url = VALUES(banner_url), location = VALUES(location), contact_email = VALUES(contact_email), phone = VALUES(phone)
    `, [sellerId, description || null, logo_url || null, banner_url || null, location || null, contact_email || null, phone || null]);
    const [userRows] = await pool.execute("SELECT user_id, username, email, brand_name, first_name, last_name FROM users WHERE user_id = ?", [sellerId]) as any;
    const [profileRows] = await pool.execute("SELECT * FROM seller_profiles WHERE seller_id = ?", [sellerId]) as any;
    res.json({ status: "success", data: { ...userRows[0], profile: profileRows[0] || null } });
  });

  app.get("/api/payment/history", async (req, res) => {
    const user = await getAuthenticatedUser(req);
    if (!user) return res.status(401).json({ status: "error", message: "Login required" });

    const { order_id } = req.query;

    if (user.role !== "admin") {
      const [ownerCheck] = await pool.execute(
        "SELECT order_id FROM orders WHERE order_id = ? AND user_id = ?",
        [order_id, user.user_id]
      ) as any;
      if (!ownerCheck.length) {
        return res.status(403).json({ status: "error", message: "Access denied" });
      }
    }

    const [history] = await pool.execute("SELECT * FROM order_status_history WHERE order_id = ?", [order_id]) as any;
    res.json({ status: "success", data: history });
  });

  app.get("/api/analytics/stats", isAdmin, async (req, res) => {

    const [salesRows] = await pool.execute("SELECT CAST(SUM(total_amount) AS DOUBLE) as total FROM orders") as any;
    const [ordersRows] = await pool.execute("SELECT COUNT(*) as count FROM orders") as any;
    const [customersRows] = await pool.execute("SELECT COUNT(*) as count FROM users WHERE role = 'customer'") as any;
    const [productsRows] = await pool.execute("SELECT COUNT(*) as count FROM products") as any;

    res.json({
      status: "success",
      data: {
        total_sales: salesRows[0].total || 0,
        total_orders: ordersRows[0].count || 0,
        total_customers: customersRows[0].count || 0,
        total_products: productsRows[0].count || 0,
      },
    });
  });

  /**
   * Admin Endpoints
   */
  app.get("/api/admin/dashboard", isAdmin, async (req, res) => {
    try {
      const [userStats] = await pool.execute(`
        SELECT
          COUNT(*) as total_users,
          SUM(status = 'active') as active_users,
          SUM(role = 'seller') as seller_count,
          SUM(role = 'customer') as customer_count,
          SUM(status = 'pending_approval' AND role = 'seller') as pending_approvals
        FROM users
        WHERE deleted_at IS NULL
      `) as any;

      const [orderStats] = await pool.execute("SELECT COUNT(*) as total_orders, CAST(SUM(total_amount) AS DOUBLE) as total_revenue FROM orders") as any;
      const [productStats] = await pool.execute("SELECT COUNT(*) as total_products FROM products WHERE deleted_at IS NULL") as any;
      
      const [recentOrders] = await pool.execute(`
        SELECT o.order_id, o.total_amount, o.status, o.created_at, u.first_name, u.last_name
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        ORDER BY o.created_at DESC
        LIMIT 5
      `) as any;

      res.json({
        status: "success",
        data: {
          ...userStats[0],
          ...orderStats[0],
          ...productStats[0],
          recent_orders: recentOrders
        }
      });
    } catch (error: any) {
      res.status(500).json({ status: "error", message: error.message });
    }
  });

  app.get("/api/admin/users", isAdmin, async (req, res) => {
    const { search, role, status } = req.query;
    let query = "SELECT user_id, username, email, first_name, last_name, brand_name, role, status, created_at FROM users WHERE deleted_at IS NULL";
    const params: any[] = [];

    if (search) {
      query += " AND (email LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR brand_name LIKE ?)";
      const s = `%${search}%`;
      params.push(s, s, s, s);
    }
    if (role) {
      query += " AND role = ?";
      params.push(role);
    }
    if (status) {
      query += " AND status = ?";
      params.push(status);
    }

    query += " ORDER BY created_at DESC";

    try {
      const [users] = await pool.execute(query, params) as any;
      res.json({ status: "success", data: users });
    } catch (error: any) {
      res.status(500).json({ status: "error", message: error.message });
    }
  });

  app.post("/api/admin/users", isAdmin, async (req, res) => {
    const { email, password, role, first_name, last_name, brand_name, status } = req.body;
    try {
      if (!password || password.length < 8) {
        return res.status(400).json({ status: "error", message: "Password must be at least 8 characters" });
      }
      const username = email.split("@")[0] + "_" + Math.floor(Math.random() * 1000);
      const hash = await bcrypt.hash(password, 10);
      await pool.execute(
        "INSERT INTO users (username, email, password_hash, role, first_name, last_name, brand_name, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [username, email, hash, role, first_name, last_name, brand_name || null, status || 'active']
      );
      res.json({ status: "success", message: "User created by admin" });
    } catch (error: any) {
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  app.put("/api/admin/users/:id", isAdmin, async (req, res) => {
    const { id } = req.params;
    const { role, status, first_name, last_name, brand_name } = req.body;
    try {
      await pool.execute(
        "UPDATE users SET role = ?, status = ?, first_name = ?, last_name = ?, brand_name = ? WHERE user_id = ?",
        [role, status, first_name, last_name, brand_name, id]
      );
      res.json({ status: "success", message: "User updated" });
    } catch (error: any) {
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  app.delete("/api/admin/users/:id", isAdmin, async (req, res) => {
    const { id } = req.params;
    const admin = (req as any).user;
    if (Number(id) === admin.user_id) {
      return res.status(400).json({ status: "error", message: "Cannot delete yourself" });
    }
    try {
      await pool.execute("UPDATE users SET deleted_at = NOW() WHERE user_id = ?", [id]);
      res.json({ status: "success", message: "User soft-deleted" });
    } catch (error: any) {
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  app.get("/api/admin/reports", isAdmin, async (req, res) => {
    try {
      const [metrics] = await pool.execute(`
        SELECT
          CAST(SUM(total_amount) AS DOUBLE) as total_revenue,
          COUNT(*) as total_orders,
          (SELECT COUNT(*) FROM users WHERE deleted_at IS NULL) as total_users,
          (SELECT COUNT(*) FROM users WHERE role = 'seller' AND status = 'active' AND deleted_at IS NULL) as active_sellers
        FROM orders
        WHERE status != 'cancelled'
      `) as any;

      const [trend] = await pool.execute(`
        SELECT DATE(created_at) as date, CAST(SUM(total_amount) AS DOUBLE) as revenue
        FROM orders
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        AND status != 'cancelled'
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at)
      `) as any;

      const [sellerBreakdown] = await pool.execute(`
        SELECT 
          u.user_id, u.first_name, u.last_name, u.brand_name, u.status,
          COUNT(oi.order_item_id) as total_items_sold,
          CAST(SUM(oi.quantity * oi.price_at_purchase) AS DOUBLE) as revenue,
          COUNT(DISTINCT o.order_id) as total_orders
        FROM users u
        LEFT JOIN products p ON u.user_id = p.seller_id
        LEFT JOIN order_items oi ON p.product_id = oi.product_id
        LEFT JOIN orders o ON oi.order_id = o.order_id
        WHERE u.role = 'seller'
        AND u.deleted_at IS NULL
        AND (o.status != 'cancelled' OR o.order_id IS NULL)
        GROUP BY u.user_id
        ORDER BY revenue DESC
        LIMIT 10
      `) as any;

      res.json({
        status: "success",
        data: {
          metrics: metrics[0],
          trend,
          sellerBreakdown
        }
      });
    } catch (error: any) {
      res.status(500).json({ status: "error", message: error.message });
    }
  });

  // Admin Categories Management
  app.get("/api/admin/categories", isAdmin, async (req, res) => {
    const [rows] = await pool.execute("SELECT * FROM categories") as any;
    res.json({ status: "success", data: rows });
  });

  app.post("/api/admin/categories", isAdmin, async (req, res) => {
    const { category_name, description } = req.body;
    try {
      const [result] = await pool.execute(
        "INSERT INTO categories (category_name, description) VALUES (?, ?)",
        [category_name, description || ""]
      ) as any;
      res.json({ status: "success", data: { category_id: result.insertId } });
    } catch (error: any) {
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  app.put("/api/admin/categories/:id", isAdmin, async (req, res) => {
    const { id } = req.params;
    const { category_name, description } = req.body;
    try {
      await pool.execute(
        "UPDATE categories SET category_name = ?, description = ? WHERE category_id = ?",
        [category_name, description, id]
      );
      res.json({ status: "success", message: "Category updated" });
    } catch (error: any) {
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  app.delete("/api/admin/categories/:id", isAdmin, async (req, res) => {
    const { id } = req.params;
    try {
      // Check if any products use this category
      const [products] = await pool.execute("SELECT 1 FROM products WHERE category_id = ? LIMIT 1", [id]) as any;
      if (products.length > 0) {
        return res.status(400).json({ status: "error", message: "Cannot delete category being used by products" });
      }
      await pool.execute("DELETE FROM categories WHERE category_id = ?", [id]);
      res.json({ status: "success", message: "Category deleted" });
    } catch (error: any) {
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  // Admin Sizes Management
  app.get("/api/admin/sizes", isAdmin, async (req, res) => {
    const [rows] = await pool.execute("SELECT * FROM sizes ORDER BY CAST(size_value AS DECIMAL(10,2)) ASC, size_value ASC") as any;
    res.json({ status: "success", data: rows });
  });

  app.post("/api/admin/sizes", isAdmin, async (req, res) => {
    const { size_value } = req.body;
    try {
      const [result] = await pool.execute(
        "INSERT INTO sizes (size_value) VALUES (?)",
        [size_value]
      ) as any;
      res.json({ status: "success", data: { size_id: result.insertId } });
    } catch (error: any) {
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  app.delete("/api/admin/sizes/:id", isAdmin, async (req, res) => {
    const { id } = req.params;
    try {
      // Check if any inventory uses this size
      const [inv] = await pool.execute("SELECT 1 FROM inventory WHERE size_id = ? LIMIT 1", [id]) as any;
      if (inv.length > 0) {
        return res.status(400).json({ status: "error", message: "Cannot delete size being used in inventory" });
      }
      await pool.execute("DELETE FROM sizes WHERE size_id = ?", [id]);
      res.json({ status: "success", message: "Size deleted" });
    } catch (error: any) {
      res.status(400).json({ status: "error", message: error.message });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.get("/manifest.webmanifest", (req, res) => {
      res.type("application/manifest+json");
      res.sendFile(path.join(distPath, "manifest.webmanifest"));
    });
    app.get("/sw.js", (req, res) => {
      res.type("application/javascript");
      res.sendFile(path.join(distPath, "sw.js"));
    });
    app.get(/^\/workbox-.+\.js$/, (req, res) => {
      res.type("application/javascript");
      res.sendFile(path.join(distPath, req.path));
    });
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
